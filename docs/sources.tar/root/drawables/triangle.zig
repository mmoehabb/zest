//! A concrete drawable to render a simple triangle by using SDL_RenderGeometry.

const std = @import("std");
const sdl = @import("sdl");
const modules = @import("../modules/mod.zig");
const types = @import("../types/mod.zig");

const Triangle = @This();

dim: types.Dimensions,
color: types.Color = .{},
_draw_strategy: modules.DrawStrategy = modules.DrawStrategy{
    .draw = draw,
    .destroy = destroy,
},

// NOTE: dimention width is considered the length of the triangle base.
pub fn new(dim: types.Dimensions, color: types.Color) Triangle {
    return Triangle{
        .dim = dim,
        .color = color,
    };
}

pub fn toDrawable(self: *Triangle) modules.Drawable {
    return modules.Drawable{
        .dim = self.dim,
        .color = self.color,
        .drawStrategy = &self._draw_strategy,
    };
}

fn draw(
    drawable: *modules.Drawable,
    _: *const modules.DrawStrategy,
    renderer: *sdl.SDL_Renderer,
    pos: types.Point,
    rot: types.Point,
    dim: types.Dimensions,
) !void {
    const color: sdl.SDL_FColor = .{
        .r = @floatFromInt(drawable.color.?.r),
        .g = @floatFromInt(drawable.color.?.g),
        .b = @floatFromInt(drawable.color.?.b),
        .a = @floatFromInt(drawable.color.?.a),
    };

    const center = .{
        .x = pos.x + (dim.w / 2),
        .y = pos.y + (dim.h / 3),
    };

    const angle = std.math.degreesToRadians(rot.z);
    const cos = @cos(angle);
    const sin = @sin(angle);
    const tan = @sin(angle);

    const pa = sdl.SDL_Vertex{
        .position = .{
            .x = center.x + (dim.h / 2 * sin) - (dim.w / 2 * cos),
            .y = center.y - (dim.w / 2 * sin) - (dim.h / 2 * cos),
        },
        .color = color,
    };
    const pb = sdl.SDL_Vertex{
        .position = .{
            .x = pa.position.x + (dim.w * cos),
            .y = pa.position.y + (dim.w * sin),
        },
        .color = color,
    };
    const pc = sdl.SDL_Vertex{
        .position = .{
            .x = center.x - ((tan * 2 * dim.h) / 3),
            .y = center.y + ((cos * 2 * dim.h) / 3),
        },
        .color = color,
    };

    const verts = [_]sdl.SDL_Vertex{ pa, pb, pc };
    const indices = [_]c_int{ 0, 1, 2 };

    if (!sdl.SDL_RenderGeometry(renderer, null, &verts, 3, &indices, 3)) {
        sdl.SDL_Log("Unable to render geometry: %s", sdl.SDL_GetError());
        return error.RenderFailed;
    }
}

fn destroy(_: *modules.Drawable, _: *const modules.DrawStrategy) void {}
